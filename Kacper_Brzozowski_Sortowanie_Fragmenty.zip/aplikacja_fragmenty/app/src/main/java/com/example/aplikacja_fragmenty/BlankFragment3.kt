package com.example.aplikacja_fragmenty

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class BlankFragment3 : Fragment() {

    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_blank3, container, false)

        val textView = view.findViewById<TextView>(R.id.textView)
        val button = view.findViewById<Button>(R.id.button3)

        // Sortowanie i wyświetlanie danych
        val editTextValue = param1.toString()
        val arr = editTextValue.split(",").map { it.toInt() }.toMutableList()

        var answer = param2.toString()

        if (param2 == "2131231088") {
            bubbleSort(arr)
            answer = "Algorytm: Sortowanie bąbelkowe\n" +
                    "Algorytm działa w ten sposób:\n" +
                    "Iteruje się po tablicy od pierwszego do przedostatniego elementu.\n" +
                    "Dla każdej iteracji, porównuje się bieżący element z następnym.\n" +
                    "Jeśli bieżący element jest większy od następnego, zamienia się je miejscami.\n" +
                    "Proces ten powtarza się dla wszystkich elementów tablicy w każdej iteracji.\n" +
                    "Tablica przed sortowaniem: $editTextValue\nTablica po sortowaniu: $arr"
        } else if (param2 == "2131231087") {
            insertionSort(arr)
            answer = "Algorytm: Sortowanie przez Wstawianie\n" +
                    "Proces ten polega na porównywaniu aktualnie rozpatrywanego\n" +
                    "elementu z poprzednimi elementami w posortowanej części\n" +
                    "tablicy i przesuwaniu większych elementów w prawo, aby\n" +
                    "zrobić miejsce dla aktualnego elementu. Algorytm kończy działanie,\n" +
                    "gdy wszystkie elementy zostaną umieszczone na właściwych pozycjach.\n" +
                    "Tablica przed sortowaniem: $editTextValue\nTablica po sortowaniu: $arr"
        }

        textView.text = answer

        // Obsługa przycisku powrotu do BlankFragment
        button.setOnClickListener {
            navigateBackToBlankFragment()
        }

        return view
    }

    private fun navigateBackToBlankFragment() {
        val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
        fragmentManager.popBackStack()
    }

    private fun bubbleSort(arr: MutableList<Int>) {
        var n = arr.size
        var czy_zmiana: Boolean
        do {
            czy_zmiana = false
            for (i in 0 until n - 1) {
                if (arr[i] > arr[i + 1]) {
                    val temp = arr[i]
                    arr[i] = arr[i + 1]
                    arr[i + 1] = temp
                    czy_zmiana = true
                }
            }
        } while (czy_zmiana)
    }

    private fun insertionSort(arr: MutableList<Int>) {
        val n = arr.size
        for (i in 1 until n) {
            val key = arr[i]
            var j = i - 1
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j]
                j--
            }
            arr[j + 1] = key
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            BlankFragment3().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
