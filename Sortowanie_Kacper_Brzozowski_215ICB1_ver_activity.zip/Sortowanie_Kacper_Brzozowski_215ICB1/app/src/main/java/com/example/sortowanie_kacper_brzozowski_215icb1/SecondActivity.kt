package com.example.sortowanie_kacper_brzozowski_215icb1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val buttonBack = findViewById<Button>(R.id.buttonBack)
        buttonBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


        val streditText = intent.getStringExtra("array")
        val arr = streditText?.split(",")?.map { it.toInt() }?.toMutableList()
        val selectedRadioButtonId = intent.getIntExtra("selectedRadioButtonId", -1)

        val textView = findViewById<TextView>(R.id.textView)
        var answer = ""

        if (selectedRadioButtonId == R.id.radioButton6) {
            bubbleSort(arr)
            answer = "Algorytm: Sortowanie bąbelkowe\n" +
                    "Algorytm działa w ten sposób:\n" +
                    "Iteruje się po tablicy od pierwszego do przedostatniego elementu.\n" +
                    "Dla każdej iteracji, porównuje się bieżący element z następnym.\n" +
                    "Jeśli bieżący element jest większy od następnego, zamienia się je miejscami.\n" +
                    "Proces ten powtarza się dla wszystkich elementów tablicy w każdej iteracji.\n" +
                    "Tablica przed sortowaniem: $streditText\nTablica po sortowaniu: $arr"
        } else if (selectedRadioButtonId == R.id.radioButton5) {
            insertionSort(arr)
            answer = "Algorytm: Sortowanie przez Wstawianie\n" +
                    "Proces ten polega na porównywaniu aktualnie rozpatrywanego\n" +
                    "elementu z poprzednimi elementami w posortowanej części\n" +
                    "tablicy i przesuwaniu większych elementów w prawo, aby\n" +
                    "zrobić miejsce dla aktualnego elementu. Algorytm kończy działanie,\n" +
                    "gdy wszystkie elementy zostaną umieszczone na właściwych pozycjach.\n" +
                    "Tablica przed sortowaniem: $streditText\nTablica po sortowaniu: $arr"
        }

        textView.text = answer
    }

    private fun bubbleSort(arr: MutableList<Int>?) {
        arr ?: return
        var n = arr.size
        var czy_zmiana: Boolean
        do {
            czy_zmiana = false
            for (i in 0 until n - 1) {
                if (arr[i] > arr[i + 1]) {
                    val temp = arr[i]
                    arr[i] = arr[i + 1]
                    arr[i + 1] = temp
                    czy_zmiana = true
                }
            }
        } while (czy_zmiana)
    }

    private fun insertionSort(arr: MutableList<Int>?) {
        arr ?: return
        val n = arr.size
        for (i in 1 until n) {
            val key = arr[i]
            var j = i - 1
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j]
                j--
            }
            arr[j + 1] = key
        }
    }
}
