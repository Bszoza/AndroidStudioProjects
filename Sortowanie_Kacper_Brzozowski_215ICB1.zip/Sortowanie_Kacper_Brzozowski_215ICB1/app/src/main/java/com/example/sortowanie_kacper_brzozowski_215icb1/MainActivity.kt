package com.example.sortowanie_kacper_brzozowski_215icb1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val radioButton = findViewById<RadioButton>(R.id.radioButton6)
        radioButton.isChecked = true

    }
    fun sort(view: View) {

     val radioGroup=findViewById<RadioGroup>(R.id.radioGroup2)
        val editText = findViewById<EditText>(R.id.editTextText);
        val streditText = editText.text.toString()
        val arr = streditText.split(",").map { it.toInt() }.toMutableList()
        var n = arr.size
        val textView = findViewById<TextView>(R.id.textView)
        var answer=""
        val checkedRadioButtonId = radioGroup.checkedRadioButtonId
            if (checkedRadioButtonId == R.id.radioButton6){



            var czy_zmiana: Boolean;//wykonuje petle dopoki nie bedzie przejscia b ezzamiany

            do {
                czy_zmiana = false
                for (i in 0 until n - 1) {
                    if (arr[i] > arr[i + 1]) {
                        // Zamiana elementów
                        val temp = arr[i]//zmienna pomocnicza
                        arr[i] = arr[i + 1]
                        arr[i + 1] = temp
                        czy_zmiana = true//dokonano zmiany wykonuje kolejne przejscie
                    }
                }
            } while (czy_zmiana)

            answer = "Algorytm: Sortowanie babelkowe\n" +
                    "Algorytm działa w ten sposób:\n" +
                    "Iteruje się po tablicy od pierwszego do przedostatniego elementu.\n" +
                    "Dla każdej iteracji, porównuje się bieżący element z następnym.\n" +
                    "Jeśli bieżący element jest większy od następnego, zamienia się je miejscami.\n" +
                    "Proces ten powtarza się dla wszystkich elementów tablicy w każdej iteracji.\n" +
                    "Tablica przed sortowaniem: "+ streditText + "\nTablica po sortowaniu: " + arr.toString();

        }
            else if (checkedRadioButtonId == R.id.radioButton5){
                for (i in 1 until n) {
                    val key = arr[i]
                    var j = i - 1
                    /* Przesuwanie elementów tablicy większych niż key, o jeden indeks w prawo */
                    while (j >= 0 && arr[j] > key) {
                        arr[j + 1] = arr[j]
                        j--
                    }
                    arr[j + 1] = key
                }

               answer = "Algorytm: Sortowanie przez Wstawianie\n" +
                       "Proces ten polega na porównywaniu aktualnie rozpatrywanego\n" +
                        "elementu z poprzednimi elementami w posortowanej części\n" +
                        "tablicy i przesuwaniu większych elementów w prawo, aby\n" +
                        "zrobić miejsce dla aktualnego elementu. Algorytm kończy działanie,\n" +
                        "gdy wszystkie elementy zostaną umieszczone na właściwych pozycjach.\n"+
                        "Tablica przed sortowaniem: "+ streditText + "\nTablica po sortowaniu: " + arr.toString();



            }
        textView.setText(answer)
}
}
